using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using DemoWeb.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Kết nối trực tiếp với SQL Server (DESKTOP-8SMUIKJ\SQLEXPRESS03 - Database: DBSportStore)
var connStr = builder.Configuration.GetConnectionString("DBSportStoreEntities")
    ?? DBSportStoreEntities.DefaultSqlServerConnection;

builder.Services.AddDbContext<DBSportStoreEntities>(options =>
    options.UseSqlServer(connStr));

builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(60);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

builder.Services.AddHttpContextAccessor();

var app = builder.Build();

// Khởi tạo Database trên SQL Server nếu chưa có, và nạp dữ liệu từ DBSportStore.sql nếu bảng còn trống
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<DBSportStoreEntities>();
    db.Database.EnsureCreated();

    if (!db.Categories.Any())
    {
        var sqlFile = Path.Combine(DBSportStoreEntities.ResolveProjectRoot(app.Environment.ContentRootPath), "DBSportStore.sql");
        if (File.Exists(sqlFile))
        {
            var sqlText = File.ReadAllText(sqlFile);
            var batches = Regex.Split(sqlText, @"^\s*GO\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);
            foreach (var batch in batches)
            {
                var trimmed = batch.Trim();
                if (string.IsNullOrEmpty(trimmed)) continue;
                // Bỏ qua các lệnh CREATE DATABASE / USE khi đang kết nối sẵn vào DBSportStore
                if (trimmed.Contains("CREATE DATABASE", StringComparison.OrdinalIgnoreCase) ||
                    trimmed.StartsWith("USE ", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }
                db.Database.ExecuteSqlRaw(trimmed);
            }
        }
    }

    if (!db.AdminUsers.Any(u => u.NameUser == "user"))
    {
        db.AdminUsers.Add(new DemoWeb.Models.AdminUser
        {
            NameUser = "user",
            RoleUser = "User",
            PasswordUser = "123456"
        });
        db.SaveChanges();
    }
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Product}/{action=Index}/{id?}");

app.Run();
