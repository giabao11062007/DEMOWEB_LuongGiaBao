using System;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DemoWeb.Data;
using DemoWeb.Helpers;
using DemoWeb.Models;

namespace DemoWeb.Controllers
{
    public class LoginUserController : Controller
    {
        private readonly DBSportStoreEntities database;

        public LoginUserController(DBSportStoreEntities db)
        {
            database = db;
        }

        // GET: LoginUser : Form Login (Lab 05 & Lab 06c)
        public ActionResult Index()
        {
            return View();
        }

        // POST: LoginAccount (Lab 05 & Lab 06c)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LoginAcount(AdminUser _user)
        {
            if (string.IsNullOrEmpty(_user.NameUser) || string.IsNullOrEmpty(_user.PasswordUser))
            {
                ViewBag.ErrorInfo = "Vui lòng nhập đầy đủ Tên đăng nhập và Mật khẩu!";
                return View("Index", _user);
            }

            int parsedId;
            bool isId = int.TryParse(_user.NameUser, out parsedId);

            var check = database.AdminUsers.FirstOrDefault(s =>
                (s.NameUser == _user.NameUser || (isId && s.ID == parsedId)) &&
                s.PasswordUser == _user.PasswordUser);

            if (check == null)
            {
                ViewBag.ErrorInfo = "SaiInfo: Tên đăng nhập hoặc mật khẩu không chính xác!";
                return View("Index", _user);
            }
            else
            {
                HttpContext.Session.SetInt32("ID", check.ID);
                HttpContext.Session.SetString("NameUser", check.NameUser);
                HttpContext.Session.SetString("PasswordUser", check.PasswordUser);
                HttpContext.Session.SetString("RoleUser", check.RoleUser ?? "User");

                // Liên kết tài khoản đăng nhập với hồ sơ Customer để tự động điền thông tin thanh toán & xem Lịch sử giao dịch
                var customer = database.Customers.FirstOrDefault(c => c.NameCus == check.NameUser);
                if (customer == null && (string.IsNullOrEmpty(check.RoleUser) || check.RoleUser.Equals("User", StringComparison.OrdinalIgnoreCase)))
                {
                    customer = new Customer
                    {
                        NameCus = check.NameUser,
                        PhoneCus = "",
                        EmailCus = ""
                    };
                    database.Customers.Add(customer);
                    database.SaveChanges();
                }

                if (customer != null)
                {
                    HttpContext.Session.SetInt32("CustomerID", customer.IDCus);
                    HttpContext.Session.SetString("CustomerName", customer.NameCus);
                }

                TempData["SuccessLogin"] = $"Đăng nhập thành công! Xin chào {check.NameUser} ({(check.RoleUser ?? "User")}).";
                if (AdminOnlyAttribute.IsAdmin(HttpContext))
                {
                    return RedirectToAction("AdminIndex", "Product");
                }
                return RedirectToAction("Index", "Product");
            }
        }

        // GET: RegisterUser (Lab 05)
        public ActionResult RegisterUser()
        {
            return View();
        }

        // POST: RegisterUser (Lab 05)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RegisterUser(AdminUser _user)
        {
            // Đăng ký công khai từ trang Khách hàng luôn mang quyền User
            _user.RoleUser = "User";

            if (ModelState.IsValid)
            {
                var check_User = database.AdminUsers.FirstOrDefault(s => s.NameUser == _user.NameUser);
                if (check_User == null)
                {
                    database.AdminUsers.Add(_user);
                    database.SaveChanges();

                    // Nếu đăng ký tài khoản User (khách hàng), tự động tạo hồ sơ bên bảng Customer để hiển thị trong Admin & dùng khi đặt hàng
                    if (_user.RoleUser.Equals("User", StringComparison.OrdinalIgnoreCase))
                    {
                        var existingCustomer = database.Customers.FirstOrDefault(c => c.NameCus == _user.NameUser);
                        if (existingCustomer == null)
                        {
                            database.Customers.Add(new Customer
                            {
                                NameCus = _user.NameUser,
                                PhoneCus = "",
                                EmailCus = ""
                            });
                            database.SaveChanges();
                        }
                    }

                    TempData["SuccessRegister"] = "Đăng ký tài khoản thành công! Vui lòng đăng nhập.";
                    return RedirectToAction("Index");
                }
                else
                {
                    ViewBag.ErrorRegister = "This ID / Username is exixst: Tên đăng nhập này đã tồn tại!";
                    return View(_user);
                }
            }
            return View(_user);
        }

        // Action LogOut (Lab 06a page 9)
        public ActionResult LogOutUser()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "LoginUser");
        }
    }
}
