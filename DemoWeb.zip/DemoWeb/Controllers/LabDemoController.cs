using Microsoft.AspNetCore.Mvc;

namespace DemoWeb.Controllers
{
    public class LabDemoController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult HtmlLabs()
        {
            return View();
        }

        public IActionResult Javascript()
        {
            return View();
        }
    }
}
