using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DemoWeb.Data;
using DemoWeb.Helpers;
using DemoWeb.Models;

namespace DemoWeb.Controllers
{
    public class ShoppingCartController : Controller
    {
        private readonly DBSportStoreEntities database;

        public ShoppingCartController(DBSportStoreEntities db)
        {
            database = db;
        }

        // Action Tạo mới giỏ hàng (Lab 06a)
        public Cart GetCart()
        {
            Cart cart = HttpContext.Session.GetObjectFromJson<Cart>("Cart");
            if (cart == null)
            {
                cart = new Cart();
                HttpContext.Session.SetObjectAsJson("Cart", cart);
            }
            return cart;
        }

        // Action thêm product vào giỏ hàng (Lab 06a)
        public ActionResult AddToCart(int id)
        {
            var _pro = database.Products.SingleOrDefault(s => s.ProductID == id);
            if (_pro != null)
            {
                Cart cart = GetCart();
                cart.Add_Product_Cart(_pro);
                HttpContext.Session.SetObjectAsJson("Cart", cart);
                TempData["CartMessage"] = $"Đã thêm sản phẩm {_pro.NamePro} vào giỏ hàng!";
            }
            return RedirectToAction("ShowCart", "ShoppingCart");
        }

        // Action hiển thị giỏ hàng (Lab 06a)
        public ActionResult ShowCart()
        {
            Cart cart = HttpContext.Session.GetObjectFromJson<Cart>("Cart");
            if (cart == null || !cart.Items.Any())
            {
                return View("EmptyCart");
            }
            return View(cart);
        }

        // Action cập nhật số lượng sản phẩm và tính lại tổng tiền (Lab 06a & Lab 07b)
        [HttpPost]
        public ActionResult Update_Cart_Quantity(IFormCollection form)
        {
            Cart cart = HttpContext.Session.GetObjectFromJson<Cart>("Cart");
            if (cart != null && form.ContainsKey("idPro") && form.ContainsKey("cartQuantity"))
            {
                if (int.TryParse(form["idPro"], out int id_pro) && int.TryParse(form["cartQuantity"], out int _quantity))
                {
                    var productInDb = database.Products.FirstOrDefault(p => p.ProductID == id_pro);
                    int maxStock = productInDb?.Quantity ?? int.MaxValue;
                    if (_quantity > maxStock)
                    {
                        _quantity = maxStock;
                        TempData["CartMessage"] = $"Số lượng tối đa còn lại trong kho của sản phẩm này là {maxStock}!";
                    }
                    if (_quantity < 0)
                    {
                        _quantity = 1;
                    }
                    cart.Update_quantity(id_pro, _quantity);
                    HttpContext.Session.SetObjectAsJson("Cart", cart);
                }
            }
            return RedirectToAction("ShowCart", "ShoppingCart");
        }

        // Action xóa dòng sản phẩm trong Giỏ hàng (Lab 06a)
        public ActionResult RemoveCart(int id)
        {
            Cart cart = HttpContext.Session.GetObjectFromJson<Cart>("Cart");
            if (cart != null)
            {
                cart.Remove_CartItem(id);
                HttpContext.Session.SetObjectAsJson("Cart", cart);
            }
            return RedirectToAction("ShowCart", "ShoppingCart");
        }

        // PartialView lấy tổng số lượng sản phẩm có trong giỏ hàng (Lab 06a)
        public ActionResult BagCart()
        {
            int toltal_quantity_item = 0;
            Cart cart = HttpContext.Session.GetObjectFromJson<Cart>("Cart");
            if (cart != null)
            {
                toltal_quantity_item = cart.Total_quantity();
            }
            ViewBag.QuantityCart = toltal_quantity_item;
            return PartialView("BagCart");
        }

        // Action CheckOut thanh toán đơn hàng (Lab 06b & Lab 07b)
        [HttpPost]
        public ActionResult CheckOut(IFormCollection form)
        {
            try
            {
                Cart cart = HttpContext.Session.GetObjectFromJson<Cart>("Cart");
                if (cart == null || !cart.Items.Any())
                {
                    TempData["ErrorCheckout"] = "Giỏ hàng rỗng, không thể thanh toán!";
                    return RedirectToAction("ShowCart", "ShoppingCart");
                }

                int customerCode;
                if (!int.TryParse(form["CodeCustomer"], out customerCode) || customerCode <= 0)
                {
                    customerCode = HttpContext.Session.GetInt32("CustomerID") ?? 1;
                }

                var customer = database.Customers.Find(customerCode);
                if (customer == null)
                {
                    var loggedUserName = HttpContext.Session.GetString("NameUser");
                    customer = new Customer
                    {
                        NameCus = !string.IsNullOrEmpty(loggedUserName) ? loggedUserName : ("Khách hàng " + customerCode),
                        PhoneCus = "0901234567",
                        EmailCus = "khachhang" + customerCode + "@sportstore.com"
                    };
                    database.Customers.Add(customer);
                    database.SaveChanges();
                }

                OrderPro _order = new OrderPro();
                _order.DateOrder = DateTime.Now;
                _order.AddressDelivery = form["AddressDelivery"];
                _order.IDCus = customer.IDCus;
                _order.TotalAmount = cart.Total_price();
                _order.PaymentStatus = "Chưa thanh toán";
                _order.PaymentMethod = "Thanh toán tiền mặt";
                _order.ShippingMethod = "Giao hàng nhanh";
                _order.OrderStatus = "Đang xử lý";
                database.OrderProes.Add(_order);
                database.SaveChanges();

                foreach (var item in cart.Items)
                {
                    OrderDetail _order_detail = new OrderDetail();
                    _order_detail.IDOrder = _order.ID;
                    _order_detail.IDProduct = item._product.ProductID;
                    _order_detail.UnitPrice = item._product.Price ?? 0;
                    _order_detail.Quantity = item._quantity;
                    database.OrderDetails.Add(_order_detail);

                    // Lab 07b: Xử lý cập nhật lại số lượng tồn trong bảng Product
                    var productInDb = database.Products.FirstOrDefault(s => s.ProductID == _order_detail.IDProduct);
                    if (productInDb != null && productInDb.Quantity != null)
                    {
                        var update_quan_pro = productInDb.Quantity - item._quantity;
                        productInDb.Quantity = update_quan_pro >= 0 ? update_quan_pro : 0;
                    }
                }

                database.SaveChanges();
                cart.ClearCart();
                HttpContext.Session.SetObjectAsJson("Cart", cart);
                HttpContext.Session.SetInt32("CustomerID", customer.IDCus);

                return RedirectToAction("CheckOut_Success", "ShoppingCart");
            }
            catch (Exception ex)
            {
                TempData["ErrorCheckout"] = "Error checkout: " + ex.Message + ". Please check information of Customer...Thanks.";
                return RedirectToAction("ShowCart", "ShoppingCart");
            }
        }

        // Action hiển thị thông báo thanh toán thành công (Lab 06b)
        public ActionResult CheckOut_Success()
        {
            return View();
        }

        // GET: ShoppingCart/MyOrders - Lịch sử giao dịch của khách hàng (Customer)
        public async Task<IActionResult> MyOrders()
        {
            int? cusId = HttpContext.Session.GetInt32("CustomerID");
            if (cusId == null)
            {
                TempData["InfoMessage"] = "Vui lòng nhập mã khách hàng hoặc thực hiện đặt hàng để xem lịch sử giao dịch.";
                return View(new System.Collections.Generic.List<OrderPro>());
            }

            var orders = await database.OrderProes
                .Include(o => o.Customer)
                .Include(o => o.OrderDetails)
                    .ThenInclude(od => od.Product)
                .Where(o => o.IDCus == cusId)
                .OrderByDescending(o => o.DateOrder)
                .ToListAsync();

            return View(orders);
        }

        // GET: ShoppingCart/MyOrderDetails/5 - Chi tiết đơn hàng của tôi
        public async Task<IActionResult> MyOrderDetails(int? id)
        {
            if (id == null) return NotFound();

            int? cusId = HttpContext.Session.GetInt32("CustomerID");

            var order = await database.OrderProes
                .Include(o => o.Customer)
                .Include(o => o.OrderDetails)
                    .ThenInclude(od => od.Product)
                .FirstOrDefaultAsync(o => o.ID == id);

            if (order == null) return NotFound();

            if (!cusId.HasValue || order.IDCus != cusId.Value)
            {
                TempData["InfoMessage"] = "Bạn không có quyền xem đơn hàng này.";
                return RedirectToAction("MyOrders");
            }

            return View(order);
        }

        // GET: ShoppingCart/MyProfile - Hồ sơ khách hàng của tài khoản đang đăng nhập
        public async Task<IActionResult> MyProfile()
        {
            int? cusId = HttpContext.Session.GetInt32("CustomerID");
            if (!cusId.HasValue)
            {
                TempData["ErrorLogin"] = "Vui lòng đăng nhập để xem hồ sơ khách hàng!";
                return RedirectToAction("Index", "LoginUser");
            }

            var customer = await database.Customers.FindAsync(cusId.Value);
            if (customer == null) return RedirectToAction("Index", "Product");

            return View(customer);
        }

        // POST: ShoppingCart/MyProfile
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MyProfile(Customer model)
        {
            int? cusId = HttpContext.Session.GetInt32("CustomerID");
            if (!cusId.HasValue)
            {
                return RedirectToAction("Index", "LoginUser");
            }

            var customer = await database.Customers.FindAsync(cusId.Value);
            if (customer == null) return NotFound();

            if (ModelState.IsValid)
            {
                customer.NameCus = model.NameCus;
                customer.PhoneCus = model.PhoneCus;
                customer.EmailCus = model.EmailCus;
                await database.SaveChangesAsync();

                HttpContext.Session.SetString("CustomerName", customer.NameCus);
                TempData["SuccessProfile"] = "Cập nhật hồ sơ khách hàng thành công!";
                return RedirectToAction("MyProfile");
            }

            return View(model);
        }
    }
}
