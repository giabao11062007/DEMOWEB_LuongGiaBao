using Microsoft.AspNetCore.Mvc;
using DemoWeb.Helpers;

namespace DemoWeb.Controllers
{
    // Alias / Chuyển hướng cho OrderProController sang OrdersController để tương thích 100%
    [AdminOnly]
    public class OrderProController : Controller
    {
        public IActionResult Index(string searchCustomer, string paymentStatus, System.DateTime? orderDate, int? page)
        {
            return RedirectToAction("Index", "Orders", new { searchCustomer, paymentStatus, orderDate, page });
        }

        public IActionResult Details(int? id)
        {
            return RedirectToAction("DetailedOrder", "Orders", new { id });
        }
    }
}
