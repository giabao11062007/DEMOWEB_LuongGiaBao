using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DemoWeb.Models
{
    public class OrderPro
    {
        public OrderPro()
        {
            OrderDetails = new HashSet<OrderDetail>();
            DateOrder = DateTime.Now;
            PaymentStatus = "Chưa thanh toán";
            PaymentMethod = "Thanh toán tiền mặt";
            ShippingMethod = "Giao hàng nhanh";
            OrderStatus = "Đang xử lý";
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Display(Name = "Mã hóa đơn")]
        public int ID { get; set; }

        [Display(Name = "Ngày đặt hàng")]
        public DateTime? DateOrder { get; set; }

        [Display(Name = "Mã khách hàng")]
        public int? IDCus { get; set; }

        [Display(Name = "Địa chỉ nhận hàng")]
        public string AddressDelivery { get; set; }

        [Display(Name = "Trạng thái thanh toán")]
        public string PaymentStatus { get; set; }

        [Display(Name = "Phương thức thanh toán")]
        public string PaymentMethod { get; set; }

        [Display(Name = "Phương thức giao hàng")]
        public string ShippingMethod { get; set; }

        [Display(Name = "Trạng thái đơn hàng")]
        public string OrderStatus { get; set; }

        [Display(Name = "Tổng giá trị")]
        [Column(TypeName = "decimal(18,2)")]
        public decimal? TotalAmount { get; set; }

        [NotMapped]
        public string AddressDeliverry
        {
            get => AddressDelivery;
            set => AddressDelivery = value;
        }

        [ForeignKey("IDCus")]
        public virtual Customer Customer { get; set; }

        public virtual ICollection<OrderDetail> OrderDetails { get; set; }
    }
}
