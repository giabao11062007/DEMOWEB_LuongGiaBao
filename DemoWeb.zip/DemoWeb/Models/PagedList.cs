using System;
using System.Collections.Generic;

namespace DemoWeb.Models
{
    // Helper class hỗ trợ phân trang (PagedList)
    public class PagedList<T> : List<T>
    {
        public int PageIndex { get; private set; }
        public int TotalPages { get; private set; }
        public int PageSize { get; private set; }
        public int TotalCount { get; private set; }

        public PagedList(List<T> items, int count, int pageIndex, int pageSize)
        {
            TotalCount = count;
            PageSize = pageSize;
            PageIndex = pageIndex;
            TotalPages = (int)Math.Ceiling(count / (double)pageSize);
            this.AddRange(items);
        }

        public bool HasPreviousPage => PageIndex > 1;
        public bool HasNextPage => PageIndex < TotalPages;

        public static PagedList<T> Create(List<T> source, int pageIndex, int pageSize)
        {
            var count = source.Count;
            var start = (pageIndex - 1) * pageSize;
            if (start < 0) start = 0;
            var items = source.GetRange(
                start,
                Math.Min(pageSize, Math.Max(0, count - start))
            );
            return new PagedList<T>(items, count, pageIndex, pageSize);
        }
    }
}
