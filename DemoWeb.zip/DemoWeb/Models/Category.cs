using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DemoWeb.Models
{
    public class Category
    {
        public Category()
        {
            Products = new HashSet<Product>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Display(Name = "ID")]
        public int Id { get; set; }

        [Display(Name = "Mã danh mục")]
        [Required(ErrorMessage = "Mã danh mục không được để trống")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Mã danh mục từ 2 đến 50 ký tự")]
        public string IDCate { get; set; }

        [Display(Name = "Tên danh mục")]
        [Required(ErrorMessage = "Tên danh mục không được để trống")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Tên danh mục từ 2 đến 100 ký tự")]
        public string NameCate { get; set; }

        public virtual ICollection<Product> Products { get; set; }
    }
}
