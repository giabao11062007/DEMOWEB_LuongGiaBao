using System;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace DemoWeb.Helpers
{
    /// <summary>
    /// Chặn tài khoản User thường / Guest truy cập các controller/action chỉ dành cho Admin.
    /// </summary>
    public class AdminOnlyAttribute : ActionFilterAttribute
    {
        public static bool IsAdmin(HttpContext context)
        {
            var session = context?.Session;
            if (session == null) return false;

            var userName = session.GetString("NameUser");
            var roleUser = session.GetString("RoleUser");

            if (string.IsNullOrEmpty(userName)) return false;

            return userName.Equals("admin", StringComparison.OrdinalIgnoreCase) ||
                   (!string.IsNullOrEmpty(roleUser) &&
                    (roleUser.Contains("Admin", StringComparison.OrdinalIgnoreCase) ||
                     roleUser.Contains("Manager", StringComparison.OrdinalIgnoreCase) ||
                     roleUser.Contains("Staff", StringComparison.OrdinalIgnoreCase)));
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var httpContext = context.HttpContext;
            if (!IsAdmin(httpContext))
            {
                var userName = httpContext.Session.GetString("NameUser");
                if (context.Controller is Controller controller)
                {
                    if (string.IsNullOrEmpty(userName))
                    {
                        controller.TempData["ErrorLogin"] = "Vui lòng đăng nhập bằng tài khoản Quản trị viên (Admin) để truy cập trang này!";
                        context.Result = new RedirectToActionResult("Index", "LoginUser", null);
                    }
                    else
                    {
                        controller.TempData["AccessDenied"] = "⛔ Bạn đang đăng nhập với quyền User, không có quyền truy cập chức năng Quản trị (Admin)!";
                        context.Result = new RedirectToActionResult("Index", "Product", null);
                    }
                }
                else
                {
                    context.Result = new RedirectToActionResult("Index", "LoginUser", null);
                }
                return;
            }

            base.OnActionExecuting(context);
        }
    }
}
